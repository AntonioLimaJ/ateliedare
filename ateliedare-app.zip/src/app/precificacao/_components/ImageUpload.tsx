"use client";

import { useState, useRef } from "react";
import { Camera, X, Lock, Heart, DollarSign, Plus } from "lucide-react";
import Image from "next/image";

interface ImageUploadProps {
  onImageProcessed: (base64: string) => void;
}

export function ImageUpload({ onImageProcessed }: ImageUploadProps) {
  const [preview, setPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new (window as any).Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        const MAX_WIDTH = 600;
        const MAX_HEIGHT = 600;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d", { alpha: false }); // Optimização: desabilita alpha se não necessário
        if (ctx) {
          ctx.imageSmoothingEnabled = true;
          ctx.imageSmoothingQuality = "medium";
          ctx.drawImage(img, 0, 0, width, height);
        }

        const webpDataUrl = canvas.toDataURL("image/webp", 0.7);
        setPreview(webpDataUrl);
        onImageProcessed(webpDataUrl);
      };
      img.src = event.target?.result;
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="w-full">
      {preview ? (
        <div className="relative w-full aspect-video rounded-3xl overflow-hidden bg-[#1e1e1e] border border-zinc-800 shadow-inner group">
          <Image src={preview} alt="Preview" fill className="object-cover" />
          <button
            onClick={() => setPreview(null)}
            className="absolute top-4 right-4 w-10 h-10 bg-black/60 backdrop-blur rounded-full flex items-center justify-center text-white shadow-lg"
          >
            <X size={20} />
          </button>
        </div>
      ) : (
        <button
          onClick={() => fileInputRef.current?.click()}
          className="w-full aspect-video rounded-[32px] bg-[#1e1e1e] flex flex-col items-center justify-center gap-2 border border-zinc-800"
        >
          <div className="w-16 h-16 border-2 border-zinc-700 border-dashed rounded-2xl flex items-center justify-center">
            <Plus className="text-zinc-700" size={32} />
          </div>
          <span className="text-sm font-medium text-zinc-600 mt-2">Editar foto</span>
        </button>
      )}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept="image/*"
        className="hidden"
      />
    </div>
  );
}
