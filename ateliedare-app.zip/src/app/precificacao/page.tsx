"use client";

import { useState } from "react";
import Link from "next/link";
import { Plus, Search, User } from "lucide-react";
import { BottomNav } from "./_components/BottomNav";
import { TopTabs } from "./_components/TopTabs";
import { ProductCard, SummaryCard } from "./_components/Cards";

export default function PrecificacaoDashboard() {
    const [activeTab, setActiveTab] = useState("produtos");

    return (
        <div className="min-h-screen bg-[#121212] text-white pb-24 font-sans antialiased selection:bg-purple-500/30">
            {/* Sticky Header */}
            <header className="sticky top-0 z-40 bg-[#1e1e1e] border-b border-zinc-800 px-6 py-4 flex items-center justify-between shadow-lg">
                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-purple-500/20 flex items-center justify-center border-2 border-[#1e1e1e] shadow-sm">
                        <User className="text-purple-400" size={20} />
                    </div>
                    <div>
                        <h1 className="text-sm font-bold text-zinc-100 leading-tight">Ateliê da Re</h1>
                        <p className="text-[11px] font-medium text-purple-400 uppercase tracking-widest">Aromas e Artes</p>
                    </div>
                </div>
                <div className="flex gap-2">
                    <button className="w-10 h-10 rounded-full bg-zinc-800/50 flex items-center justify-center text-zinc-400 hover:text-white transition-colors">
                        <Search size={20} />
                    </button>
                </div>
            </header>

            <main className="pt-6">
                {/* Welcome Section */}
                <div className="px-6 mb-6">
                    <h2 className="text-2xl font-bold tracking-tight text-white">Olá, Regina! 👋</h2>
                    <p className="text-zinc-500 mt-1">Pronta para precificar?</p>
                </div>

                {/* Dynamic Summary based on Tab */}
                <div className="mx-4 mb-6">
                    {activeTab === "produtos" ? (
                        <div className="p-6 rounded-3xl bg-purple-600 text-white shadow-xl shadow-purple-900/20">
                            <p className="text-sm font-medium text-purple-100">Valor Total em Estoque</p>
                            <p className="text-2xl font-bold mt-1 tracking-tight">R$ 0,00</p>
                        </div>
                    ) : activeTab === "materiais" ? (
                        <div className="p-6 rounded-3xl bg-[#1e1e1e] border border-zinc-800 text-white shadow-lg">
                            <p className="text-sm font-medium text-zinc-500">Materiais Cadastrados</p>
                            <p className="text-2xl font-bold mt-1 tracking-tight">0 itens</p>
                        </div>
                    ) : (
                        <div className="p-6 rounded-3xl bg-[#1e1e1e] border border-zinc-800 text-white shadow-lg">
                            <p className="text-sm font-medium text-zinc-500">Custo Fixo Mensal</p>
                            <p className="text-2xl font-bold mt-1 tracking-tight">R$ 0,00</p>
                        </div>
                    )}
                </div>

                {/* Tab Navigation (Ajustado para Dark) */}
                <TopTabs activeTab={activeTab} onTabChange={setActiveTab} />

                {/* Items List */}
                <div className="space-y-1 py-12 flex flex-col items-center justify-center text-zinc-600">
                    <div className="w-16 h-16 rounded-full bg-zinc-800/30 flex items-center justify-center mb-4">
                        <Plus size={32} />
                    </div>
                    <p className="text-sm font-medium">Nenhum item encontrado</p>
                </div>
            </main>

            {/* Floating Action Button */}
            <Link
                href="/precificacao/novo"
                className="fixed right-6 bottom-24 w-14 h-14 bg-purple-500 rounded-full flex items-center justify-center text-white shadow-xl shadow-purple-900/40 active:scale-95 transition-transform z-50"
            >
                <Plus size={28} />
            </Link>

            {/* Navigation */}
            <BottomNav />
        </div>
    );
}
