"use client";

import { Edit2, ChevronDown } from "lucide-react";

interface PricingTableProps {
  laborValue: number;
  materialsCost: number;
  totalCost: number;
  profit: number;
  taxes: number;
  suggestedPrice: number;
  onEditPrice: () => void;
}

export function PricingTable({
  laborValue,
  materialsCost,
  totalCost,
  profit,
  taxes,
  suggestedPrice,
  onEditPrice,
}: PricingTableProps) {
  return (
    <div className="bg-[#1e1e1e] rounded-xl p-6 shadow-xl space-y-6">
      <div className="space-y-1">
        <h3 className="text-sm font-bold text-zinc-100">Total</h3>
        <p className="text-2xl font-bold text-sky-400">R$ {suggestedPrice.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</p>
      </div>

      <div className="space-y-4 pt-4">
        {/* Preço Base Node */}
        <div className="flex justify-between items-center text-xs font-bold text-zinc-100 uppercase tracking-tight">
          <div className="flex items-center gap-1">
            <ChevronDown size={14} className="text-zinc-500" />
            <span>Preço Base</span>
          </div>
          <span className="text-sky-400/80">R$ {(totalCost + profit).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
        </div>

        {/* Custo Total Node */}
        <div className="pl-4 space-y-3 border-l border-zinc-800 ml-1.5">
          <div className="flex justify-between items-center text-xs font-bold text-zinc-300">
            <div className="flex items-center gap-1">
              <ChevronDown size={14} className="text-zinc-600" />
              <span>Custo total</span>
            </div>
            <span>R$ {totalCost.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
          </div>

          {/* Leaf Nodes */}
          <div className="pl-6 space-y-3">
            <div className="flex justify-between items-center text-xs text-zinc-400">
              <span>Materiais</span>
              <span>R$ {materialsCost.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
            </div>
            <div className="flex justify-between items-center text-xs text-zinc-400">
              <span>Trabalho</span>
              <span>R$ {laborValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
            </div>
          </div>

          <div className="flex justify-between items-center text-xs font-bold text-zinc-300">
            <span>Lucro</span>
            <span>R$ {profit.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
          </div>
        </div>

        {/* Taxas Node */}
        <div className="flex justify-between items-center text-xs font-bold text-zinc-300">
          <span>Taxas</span>
          <span className="text-zinc-400">R$ {taxes.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
        </div>
      </div>

      <button 
        onClick={onEditPrice}
        className="w-full mt-4 flex items-center justify-center gap-2 py-3 rounded-xl border border-zinc-700 text-zinc-300 font-bold text-sm hover:bg-white/5 transition-colors"
      >
        <Edit2 size={16} />
        Editar preço final
      </button>
    </div>
  );
}
